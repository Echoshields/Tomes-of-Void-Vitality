/**
 * Vial Coating automation — Tomes of Void & Vitality
 *
 * Weapons with the "vial-coating" trait can have a vial loaded into them
 * (1 reload/Interact action). While a vial is loaded, every shot fired from
 * that weapon counts as the vial's special material (silver, cold iron,
 * adamantine) for the purpose of weaknesses and resistances, and expends one
 * use of the vial. When the vial's uses reach 0 it is destroyed. A loaded
 * vial can be removed from the weapon, keeping its remaining uses.
 *
 * Flow:
 *  - Player clicks "Use" on a vial consumable → we intercept the consume.
 *  - If the vial is not loaded: pick an equipped weapon with the vial-coating
 *    trait and load the vial into it. A "Vial Coating" effect with an
 *    AdjustStrike rule element (property: materials) is applied to the actor,
 *    scoped to that weapon by item id, with a badge showing uses remaining.
 *  - If the vial is already loaded: unload it, keeping remaining uses.
 *  - Each attack roll with the weapon decrements the vial. The final shot is
 *    still coated: the vial/effect are removed after that shot's damage roll
 *    (or before the following attack if the shot missed).
 */

const MODULE_ID = "tomes-of-void-and-vitality";
const TRAIT = "vial-coating";
const DATA_VERSION = "3";

const ICONS = {
  vial: "systems/pf2e/icons/default-icons/consumable.svg",
  effect: "systems/pf2e/icons/default-icons/effect.svg",
};

const VIALS = {
  "silver-vial": {
    slug: "silver-vial",
    name: "Silver Vial",
    label: "Silver",
    material: "silver",
    level: 3,
    priceGp: 6,
    uses: 10,
  },
  "cold-iron-vial": {
    slug: "cold-iron-vial",
    name: "Cold Iron Vial",
    label: "Cold Iron",
    material: "cold-iron",
    level: 3,
    priceGp: 6,
    uses: 10,
  },
  "adamantine-vial": {
    slug: "adamantine-vial",
    name: "Adamantine Vial",
    label: "Adamantine",
    material: "adamantine",
    level: 11,
    priceGp: 350,
    uses: 5,
  },
};

/* -------------------------------------------- */
/*  Item data builders                          */
/* -------------------------------------------- */

function vialDescription(def) {
  return (
    `<p>A slender alchemical vial designed to feed into weapons with the ` +
    `<strong>Vial Coating</strong> trait. Loading the vial into such a weapon ` +
    `is a reload action (<span class="action-glyph">1</span> unless the weapon ` +
    `says otherwise). While loaded, every shot fired from the weapon counts as ` +
    `<strong>${def.label.toLowerCase()}</strong> for the purpose of weaknesses ` +
    `and resistances, and expends one use of the vial. When its last use is ` +
    `expended the vial is destroyed.</p>` +
    `<p>The vial holds enough coating for ${def.uses} rounds. It can be removed ` +
    `from the weapon, keeping its remaining uses.</p>`
  );
}

function vialItemData(def) {
  return {
    name: def.name,
    type: "consumable",
    img: ICONS.vial,
    system: {
      slug: def.slug,
      description: { value: vialDescription(def) },
      level: { value: def.level },
      traits: { value: ["alchemical", "consumable"], rarity: "common" },
      quantity: 1,
      bulk: { value: 0.1 },
      price: { value: { gp: def.priceGp }, per: 1 },
      category: "oil",
      uses: { value: def.uses, max: def.uses, autoDestroy: true },
      usage: { value: "held-in-one-hand" },
      rules: [],
    },
  };
}

/**
 * Effect applied to the actor while a vial is loaded. When a weapon and vial
 * are passed, the AdjustStrike rule is scoped to that weapon's item id and the
 * effect tracks the vial; without them (compendium reference copy) it applies
 * to any weapon with the vial-coating trait.
 */
function coatingEffectData(def, weapon = null, vial = null) {
  const definition = [`item:trait:${TRAIT}`];
  const flags = { vialCoating: def.material, depleted: false };
  const badge = vial
    ? { type: "counter", value: vial.system.uses?.value ?? def.uses }
    : null;
  if (weapon) {
    // Scope by item id rather than slug: identical weapons share a slug, but
    // the vial belongs to the specific weapon it was loaded into.
    definition.push(`item:id:${weapon.id}`);
    flags.weaponId = weapon.id;
    flags.weaponName = weapon.name;
  }
  if (vial) flags.vialId = vial.id;
  return {
    name: `Effect: Vial Coating (${def.label})`,
    type: "effect",
    img: ICONS.effect,
    flags: { [MODULE_ID]: flags },
    system: {
      slug: `effect-vial-coating-${def.material}`,
      description: {
        value:
          `<p>A vial is loaded into the weapon. Shots fired from it count as ` +
          `<strong>${def.label.toLowerCase()}</strong> for the purpose of ` +
          `weaknesses and resistances. Each shot expends one use of the vial; ` +
          `when its last use is expended the vial is destroyed. Removing the ` +
          `effect unloads the vial, keeping its remaining uses.</p>`,
      },
      level: { value: def.level },
      duration: { value: -1, unit: "unlimited", expiry: null, sustained: false },
      tokenIcon: { show: true },
      badge,
      rules: [
        {
          key: "AdjustStrike",
          mode: "add",
          property: "materials",
          value: def.material,
          definition,
        },
      ],
    },
  };
}

/* -------------------------------------------- */
/*  Loading and unloading vials                 */
/* -------------------------------------------- */

/**
 * Identify a vial by slug, falling back to the sluggified name so hand-made
 * copies without a system slug (e.g. items created directly in Foundry) still
 * trigger the automation.
 */
function vialDefFor(item) {
  const slug = item.slug ?? game.pf2e.system.sluggify(item.name ?? "");
  return VIALS[slug] ?? null;
}

function coatingEffects(actor) {
  return actor?.itemTypes.effect.filter((e) => e.flags[MODULE_ID]?.vialCoating) ?? [];
}

function effectForVial(actor, vial) {
  return coatingEffects(actor).find((e) => e.flags[MODULE_ID]?.vialId === vial.id) ?? null;
}

function effectsForWeapon(actor, weaponId) {
  return coatingEffects(actor).filter((e) => e.flags[MODULE_ID]?.weaponId === weaponId);
}

function eligibleWeapons(actor) {
  return actor.itemTypes.weapon.filter(
    (w) => w.system.traits.value.includes(TRAIT) && (w.isEquipped ?? true)
  );
}

async function pickWeapon(weapons) {
  if (weapons.length === 1) return weapons[0];
  const options = weapons
    .map((w) => `<option value="${w.id}">${w.name}</option>`)
    .join("");
  const id = await foundry.applications.api.DialogV2.prompt({
    window: { title: "Vial Coating" },
    content:
      `<p>Load the vial into which weapon?</p>` +
      `<select name="weapon" style="width: 100%;">${options}</select>`,
    ok: {
      label: "Load Vial",
      callback: (_event, button) => button.form.elements.weapon.value,
    },
  }).catch(() => null);
  return weapons.find((w) => w.id === id) ?? null;
}

/** Use on an unloaded vial: load it into a weapon. */
async function loadVial(vial) {
  const def = vialDefFor(vial);
  const actor = vial.actor;

  const weapons = eligibleWeapons(actor);
  if (weapons.length === 0) {
    ui.notifications.warn(
      `${actor.name} has no equipped weapon with the Vial Coating trait.`
    );
    return;
  }

  const weapon = await pickWeapon(weapons);
  if (!weapon) return;

  // One vial per weapon: unload any vial already in this weapon. Deleting the
  // effect clears the old vial's loaded flag via the deleteItem hook.
  const existing = effectsForWeapon(actor, weapon.id);
  if (existing.length > 0) {
    await actor.deleteEmbeddedDocuments("Item", existing.map((e) => e.id));
  }

  // Loading one vial out of a stack: split a single vial off first so uses
  // are tracked on the loaded item alone.
  if ((vial.quantity ?? 1) > 1) {
    await vial.update({ "system.quantity": vial.quantity - 1 });
    const source = vial.toObject();
    delete source._id;
    source.system.quantity = 1;
    const [split] = await actor.createEmbeddedDocuments("Item", [source]);
    vial = split;
  }

  await actor.createEmbeddedDocuments("Item", [coatingEffectData(def, weapon, vial)]);
  await vial.update({ [`flags.${MODULE_ID}.loadedWeaponId`]: weapon.id });

  await ChatMessage.implementation.create({
    speaker: ChatMessage.implementation.getSpeaker({ actor }),
    flavor: `<strong>Load ${def.name}</strong> <span class="action-glyph">1</span> (Interact, reload)`,
    content:
      `<p>${actor.name} loads a ${def.label.toLowerCase()} vial into the ` +
      `${weapon.name}. Its shots count as ${def.label.toLowerCase()} for ` +
      `weaknesses and resistances until the vial's ` +
      `${vial.system.uses?.value ?? def.uses} remaining uses are expended.</p>`,
  });
}

/** Use on a loaded vial: remove it from the weapon, keeping remaining uses. */
async function unloadVial(vial) {
  const def = vialDefFor(vial);
  const actor = vial.actor;
  const effect = effectForVial(actor, vial);
  const weaponName =
    effect?.flags[MODULE_ID]?.weaponName ??
    actor.items.get(vial.flags[MODULE_ID]?.loadedWeaponId ?? "")?.name ??
    "weapon";

  if (effect) await effect.delete();
  await vial.update({ [`flags.${MODULE_ID}.-=loadedWeaponId`]: null });

  await ChatMessage.implementation.create({
    speaker: ChatMessage.implementation.getSpeaker({ actor }),
    flavor: `<strong>Remove ${def.name}</strong> <span class="action-glyph">1</span> (Interact)`,
    content:
      `<p>${actor.name} removes the ${def.label.toLowerCase()} vial from the ` +
      `${weaponName}. It has ${vial.system.uses?.value ?? 0} uses remaining.</p>`,
  });
}

/** Entry point from the consume patch: toggle between loading and unloading. */
async function applyVial(vial) {
  const def = vialDefFor(vial);
  const actor = vial.actor;
  if (!def || !actor) return;
  if (vial.flags[MODULE_ID]?.loadedWeaponId) return unloadVial(vial);
  return loadVial(vial);
}

/* -------------------------------------------- */
/*  Per-shot depletion                          */
/* -------------------------------------------- */

/** Delete a depleted vial and its effect, announcing the expenditure. */
async function expendVial(actor, effect, vial) {
  await effect.delete();
  if (vial) {
    const name = vial.name;
    await vial.delete();
    await ChatMessage.implementation.create({
      speaker: ChatMessage.implementation.getSpeaker({ actor }),
      content: `<p>The ${name} is expended and crumbles away.</p>`,
    });
  }
}

async function onAttackOrDamageMessage(message) {
  // Only the message author manages the vial, so it is handled exactly once.
  if (game.user.id !== message.author?.id) return;

  const ctx = message.flags?.pf2e?.context;
  if (!ctx || !["attack-roll", "damage-roll"].includes(ctx.type)) return;
  const options = ctx.options ?? [];
  if (!options.includes(`item:trait:${TRAIT}`)) return;

  const actor =
    message.actor ?? ChatMessage.implementation.getSpeakerActor(message.speaker);
  if (!actor) return;

  const effects = coatingEffects(actor).filter((e) => {
    const weaponId = e.flags[MODULE_ID]?.weaponId;
    return weaponId && options.includes(`item:id:${weaponId}`);
  });

  for (const effect of effects) {
    const flags = effect.flags[MODULE_ID];
    const vial = actor.items.get(flags.vialId ?? "");

    if (ctx.type === "attack-roll") {
      if (flags.depleted) {
        // The final coated shot missed (no damage was rolled). This new shot
        // is uncoated; clean up now. Deleting here is safe: materials only
        // matter when damage is rolled, which happens after this message.
        await expendVial(actor, effect, vial);
        continue;
      }
      if (!vial) {
        // The vial is gone (sold, deleted, moved): the coating cannot persist.
        await effect.delete();
        continue;
      }
      const remaining = (vial.system.uses?.value ?? 1) - 1;
      if (remaining > 0) {
        await vial.update({ "system.uses.value": remaining });
        await effect.update({ "system.badge.value": remaining });
      } else {
        // Last use: keep the effect until this shot's damage is rolled so the
        // material still applies. The badge stays at 1 for the final round.
        await vial.update({ "system.uses.value": 0 });
        await effect.update({ [`flags.${MODULE_ID}.depleted`]: true });
      }
    } else if (flags.depleted) {
      // Damage has been rolled with the material applied; the vial is spent.
      await expendVial(actor, effect, vial);
    }
  }
}

/** Keep vials and effects in sync when either side is deleted directly. */
async function onDeleteItem(item, _options, userId) {
  if (userId !== game.user.id) return;
  const actor = item.actor;
  if (!actor) return;

  const flags = item.flags?.[MODULE_ID];
  if (item.type === "effect" && flags?.vialCoating && flags.vialId) {
    // Effect removed: unload the linked vial, keeping its remaining uses.
    const vial = actor.items.get(flags.vialId);
    if (vial?.flags[MODULE_ID]?.loadedWeaponId) {
      await vial.update({ [`flags.${MODULE_ID}.-=loadedWeaponId`]: null });
    }
  } else if (item.type === "consumable" && vialDefFor(item)) {
    // Vial removed: its coating cannot remain on the weapon.
    const orphaned = coatingEffects(actor).filter(
      (e) => e.flags[MODULE_ID]?.vialId === item.id
    );
    if (orphaned.length > 0) {
      await actor.deleteEmbeddedDocuments("Item", orphaned.map((e) => e.id));
    }
  } else if (item.type === "weapon") {
    // Weapon removed: unload any vial it carried (effect deletion clears the
    // vial's loaded flag via this same hook).
    const orphaned = effectsForWeapon(actor, item.id);
    if (orphaned.length > 0) {
      await actor.deleteEmbeddedDocuments("Item", orphaned.map((e) => e.id));
    }
  }
}

/* -------------------------------------------- */
/*  Compendium seeding                          */
/* -------------------------------------------- */

/**
 * Module-managed fields on existing same-name pack items (e.g. hand-made
 * before this script existed, or seeded by an older version) are kept in
 * sync; other fields are left as the user set them.
 */
const REPAIR_KEYS = ["system.slug", "system.description.value", "system.uses.max"];

async function seedPack(packId, documents) {
  const pack = game.packs.get(packId);
  if (!pack) {
    console.warn(`${MODULE_ID} | Compendium ${packId} not found; skipping seeding.`);
    return;
  }
  const existingNames = new Set(pack.index.map((entry) => entry.name));
  const missing = documents.filter((doc) => !existingNames.has(doc.name));

  const repairs = [];
  for (const doc of documents.filter((d) => existingNames.has(d.name))) {
    const entries = pack.index.filter((entry) => entry.name === doc.name);
    for (const entry of entries) {
      const existing = await pack.getDocument(entry._id);
      if (!existing || existing.type !== doc.type) continue;
      const update = {};
      for (const key of REPAIR_KEYS) {
        const expected = foundry.utils.getProperty(doc, key);
        if (expected === undefined) continue;
        if (foundry.utils.getProperty(existing._source, key) !== expected) {
          update[key] = expected;
        }
      }
      if (!foundry.utils.isEmpty(update)) repairs.push({ document: existing, update });
    }
  }

  if (missing.length === 0 && repairs.length === 0) return;

  const wasLocked = pack.locked;
  if (wasLocked) await pack.configure({ locked: false });
  try {
    if (missing.length > 0) {
      await Item.implementation.createDocuments(missing, { pack: packId });
      console.log(
        `${MODULE_ID} | Added to ${packId}: ${missing.map((d) => d.name).join(", ")}`
      );
    }
    for (const { document, update } of repairs) {
      await document.update(update);
      console.log(`${MODULE_ID} | Updated ${document.name} in ${packId}.`);
    }
  } finally {
    if (wasLocked) await pack.configure({ locked: true });
  }
}

async function seedCompendia() {
  const defs = Object.values(VIALS);
  await seedPack(`${MODULE_ID}.items`, defs.map((def) => vialItemData(def)));
  await seedPack(`${MODULE_ID}.effects`, defs.map((def) => coatingEffectData(def)));
}

/* -------------------------------------------- */
/*  Hooks                                       */
/* -------------------------------------------- */

Hooks.once("setup", () => {
  game.settings.register(MODULE_ID, "vialDataVersion", {
    scope: "world",
    config: false,
    type: String,
    default: "",
  });

  // Intercept vial consumption: using a vial loads/unloads it instead of the
  // default consume behavior.
  const Consumable = CONFIG.PF2E?.Item?.documentClasses?.consumable;
  if (Consumable?.prototype?.consume) {
    const original = Consumable.prototype.consume;
    Consumable.prototype.consume = async function (...args) {
      if (vialDefFor(this)) return applyVial(this);
      return original.apply(this, args);
    };
  } else {
    console.error(
      `${MODULE_ID} | Could not patch consumable use; vial coating automation disabled.`
    );
  }
});

Hooks.once("ready", async () => {
  const module = game.modules.get(MODULE_ID);
  module.api = { applyVial, seedCompendia };

  Hooks.on("createChatMessage", (message) => {
    onAttackOrDamageMessage(message).catch((error) =>
      console.error(`${MODULE_ID} | Vial coating depletion failed`, error)
    );
  });

  Hooks.on("deleteItem", (item, options, userId) => {
    onDeleteItem(item, options, userId).catch((error) =>
      console.error(`${MODULE_ID} | Vial coating cleanup failed`, error)
    );
  });

  if (game.user.isGM) {
    const seeded = game.settings.get(MODULE_ID, "vialDataVersion");
    if (seeded !== DATA_VERSION) {
      await seedCompendia();
      await game.settings.set(MODULE_ID, "vialDataVersion", DATA_VERSION);
    }
  }
});
