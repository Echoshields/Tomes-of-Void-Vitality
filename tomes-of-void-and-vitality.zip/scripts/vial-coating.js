/**
 * Vial Coating automation — Tomes of Void & Vitality
 *
 * Weapons with the "vial-coating" trait can have a vial applied (1 reload/Interact
 * action). The vial coats the next piece of ammunition loaded in the weapon, making
 * that shot count as the vial's special material (silver, cold iron, adamantine)
 * for the purpose of weaknesses and resistances.
 *
 * Flow:
 *  - Player clicks "Use" on a vial consumable → we intercept the consume.
 *  - We require an equipped weapon with the vial-coating trait that has ammunition
 *    loaded (selected ammo with quantity/uses remaining). No weapon → no vial spent.
 *  - A "Vial Coating" effect with an AdjustStrike rule element (property: materials)
 *    is applied to the actor, scoped to the chosen weapon.
 *  - The effect is marked spent when that weapon makes its next attack roll and is
 *    deleted after the damage roll (or before the following attack if the shot
 *    missed), so exactly one fired round benefits.
 */

const MODULE_ID = "tomes-of-void-and-vitality";
const TRAIT = "vial-coating";
const DATA_VERSION = "2";

const ICONS = {
  vial: "systems/pf2e/icons/default-icons/consumable.svg",
  effect: "systems/pf2e/icons/default-icons/effect.svg",
};

const VIALS = {
  "silver-vial": {
    slug: "silver-vial",
    name: "Silver Vial",
    label: "Silver",
    material: "silver",
    level: 3,
    priceGp: 6,
    uses: 10,
  },
  "cold-iron-vial": {
    slug: "cold-iron-vial",
    name: "Cold Iron Vial",
    label: "Cold Iron",
    material: "cold-iron",
    level: 3,
    priceGp: 6,
    uses: 10,
  },
  "adamantine-vial": {
    slug: "adamantine-vial",
    name: "Adamantine Vial",
    label: "Adamantine",
    material: "adamantine",
    level: 11,
    priceGp: 350,
    uses: 5,
  },
};

/* -------------------------------------------- */
/*  Item data builders                          */
/* -------------------------------------------- */

function vialDescription(def) {
  return (
    `<p>A slender alchemical vial designed to feed into weapons with the ` +
    `<strong>Vial Coating</strong> trait. Applying a vial coat is a reload action ` +
    `(<span class="action-glyph">1</span> unless the weapon says otherwise) and ` +
    `coats the next piece of ammunition loaded in the weapon, causing that shot to ` +
    `count as <strong>${def.label.toLowerCase()}</strong> for the purpose of ` +
    `weaknesses and resistances.</p>` +
    `<p>The vial holds enough coating for ${def.uses} rounds.</p>`
  );
}

function vialItemData(def) {
  return {
    name: def.name,
    type: "consumable",
    img: ICONS.vial,
    system: {
      slug: def.slug,
      description: { value: vialDescription(def) },
      level: { value: def.level },
      traits: { value: ["alchemical", "consumable"], rarity: "common" },
      quantity: 1,
      bulk: { value: 0.1 },
      price: { value: { gp: def.priceGp }, per: 1 },
      category: "oil",
      uses: { value: def.uses, max: def.uses, autoDestroy: true },
      usage: { value: "held-in-one-hand" },
      rules: [],
    },
  };
}

/**
 * Effect applied to the actor. When a weapon is passed, the AdjustStrike rule is
 * scoped to that weapon's slug; without one (compendium reference copy) it applies
 * to any weapon with the vial-coating trait.
 */
function coatingEffectData(def, weapon = null) {
  const definition = [`item:trait:${TRAIT}`];
  const flags = { vialCoating: def.material, spent: false };
  if (weapon) {
    const slug = weapon.slug ?? game.pf2e.system.sluggify(weapon.name);
    definition.push(`item:slug:${slug}`);
    flags.weaponSlug = slug;
    flags.weaponName = weapon.name;
  }
  return {
    name: `Effect: Vial Coating (${def.label})`,
    type: "effect",
    img: ICONS.effect,
    flags: { [MODULE_ID]: flags },
    system: {
      slug: `effect-vial-coating-${def.material}`,
      description: {
        value:
          `<p>The next piece of ammunition fired from the coated weapon counts as ` +
          `<strong>${def.label.toLowerCase()}</strong> for the purpose of weaknesses ` +
          `and resistances. The coating is expended with the next shot, hit or miss.</p>`,
      },
      level: { value: def.level },
      duration: { value: -1, unit: "unlimited", expiry: null, sustained: false },
      tokenIcon: { show: true },
      rules: [
        {
          key: "AdjustStrike",
          mode: "add",
          property: "materials",
          value: def.material,
          definition,
        },
      ],
    },
  };
}

/* -------------------------------------------- */
/*  Applying a vial                             */
/* -------------------------------------------- */

/**
 * Identify a vial by slug, falling back to the sluggified name so hand-made
 * copies without a system slug (e.g. items created directly in Foundry) still
 * trigger the automation.
 */
function vialDefFor(item) {
  const slug = item.slug ?? game.pf2e.system.sluggify(item.name ?? "");
  return VIALS[slug] ?? null;
}

function isLoaded(weapon) {
  const ammo = weapon.ammo;
  if (!ammo) return false;
  const quantity = ammo.quantity ?? 0;
  const uses = ammo.system?.uses?.value ?? 0;
  return quantity > 0 || uses > 0;
}

function eligibleWeapons(actor) {
  return actor.itemTypes.weapon.filter(
    (w) => w.system.traits.value.includes(TRAIT) && (w.isEquipped ?? true)
  );
}

async function pickWeapon(weapons) {
  if (weapons.length === 1) return weapons[0];
  const options = weapons
    .map((w) => `<option value="${w.id}">${w.name}</option>`)
    .join("");
  const id = await foundry.applications.api.DialogV2.prompt({
    window: { title: "Vial Coating" },
    content:
      `<p>Apply the vial coat to which weapon?</p>` +
      `<select name="weapon" style="width: 100%;">${options}</select>`,
    ok: {
      label: "Apply Coating",
      callback: (_event, button) => button.form.elements.weapon.value,
    },
  }).catch(() => null);
  return weapons.find((w) => w.id === id) ?? null;
}

/** Decrement one use of the vial, mirroring the system's auto-destroy behavior. */
async function spendVialUse(vial) {
  const uses = vial.system.uses ?? { value: 1, max: 1, autoDestroy: true };
  const remaining = (uses.value ?? 1) - 1;
  if (remaining > 0) {
    return vial.update({ "system.uses.value": remaining });
  }
  if ((vial.quantity ?? 1) > 1) {
    return vial.update({
      "system.quantity": vial.quantity - 1,
      "system.uses.value": uses.max,
    });
  }
  if (uses.autoDestroy ?? true) return vial.delete();
  return vial.update({ "system.uses.value": 0 });
}

async function applyVial(vial) {
  const def = vialDefFor(vial);
  const actor = vial.actor;
  if (!def || !actor) return;

  const weapons = eligibleWeapons(actor);
  if (weapons.length === 0) {
    ui.notifications.warn(
      `${actor.name} has no equipped weapon with the Vial Coating trait.`
    );
    return;
  }

  const loaded = weapons.filter(isLoaded);
  if (loaded.length === 0) {
    ui.notifications.warn(
      "The weapon must be loaded before a vial coat can be applied " +
        "(select ammunition with at least one round remaining)."
    );
    return;
  }

  const weapon = await pickWeapon(loaded);
  if (!weapon) return;

  // Only one coating at a time: remove any existing coating effects first.
  const existing = actor.itemTypes.effect.filter(
    (e) => e.flags[MODULE_ID]?.vialCoating
  );
  if (existing.length > 0) {
    await actor.deleteEmbeddedDocuments(
      "Item",
      existing.map((e) => e.id)
    );
  }

  await actor.createEmbeddedDocuments("Item", [coatingEffectData(def, weapon)]);
  await spendVialUse(vial);

  await ChatMessage.implementation.create({
    speaker: ChatMessage.implementation.getSpeaker({ actor }),
    flavor: `<strong>${def.name}</strong> <span class="action-glyph">1</span> (Interact, reload)`,
    content:
      `<p>${actor.name} feeds a ${def.label.toLowerCase()} vial coat into the ` +
      `${weapon.name}. Its next shot counts as ${def.label.toLowerCase()} for ` +
      `weaknesses and resistances.</p>`,
  });
}

/* -------------------------------------------- */
/*  Coating expiry (one shot per coat)          */
/* -------------------------------------------- */

function coatingEffects(actor) {
  return actor?.itemTypes.effect.filter((e) => e.flags[MODULE_ID]?.vialCoating) ?? [];
}

function effectMatchesContext(effect, options) {
  const slug = effect.flags[MODULE_ID]?.weaponSlug;
  return !slug || options.includes(`item:slug:${slug}`);
}

async function onAttackOrDamageMessage(message) {
  // Only the message author manages the effect, so it is handled exactly once.
  if (game.user.id !== message.author?.id) return;

  const ctx = message.flags?.pf2e?.context;
  if (!ctx || !["attack-roll", "damage-roll"].includes(ctx.type)) return;
  const options = ctx.options ?? [];
  if (!options.includes(`item:trait:${TRAIT}`)) return;

  const actor =
    message.actor ?? ChatMessage.implementation.getSpeakerActor(message.speaker);
  const effects = coatingEffects(actor).filter((e) =>
    effectMatchesContext(e, options)
  );
  if (effects.length === 0) return;

  if (ctx.type === "attack-roll") {
    // A spent coating still present means the previous shot missed (no damage was
    // rolled). This new shot is uncoated ammo, so remove the effect now. Deleting
    // here is safe: materials only matter when damage is rolled, which happens
    // after this message.
    const spent = effects.filter((e) => e.flags[MODULE_ID]?.spent);
    const fresh = effects.filter((e) => !e.flags[MODULE_ID]?.spent);
    if (spent.length > 0) {
      await actor.deleteEmbeddedDocuments("Item", spent.map((e) => e.id));
    }
    for (const effect of fresh) {
      await effect.update({ [`flags.${MODULE_ID}.spent`]: true });
    }
  } else {
    // Damage has been rolled with the material applied; the coat is used up.
    const spent = effects.filter((e) => e.flags[MODULE_ID]?.spent);
    if (spent.length > 0) {
      await actor.deleteEmbeddedDocuments("Item", spent.map((e) => e.id));
    }
  }
}

/* -------------------------------------------- */
/*  Compendium seeding                          */
/* -------------------------------------------- */

async function seedPack(packId, documents) {
  const pack = game.packs.get(packId);
  if (!pack) {
    console.warn(`${MODULE_ID} | Compendium ${packId} not found; skipping seeding.`);
    return;
  }
  const existingNames = new Set(pack.index.map((entry) => entry.name));
  const missing = documents.filter((doc) => !existingNames.has(doc.name));

  // Existing same-name items (e.g. hand-made before this script existed) are kept,
  // but their system slug must match what the automation looks for.
  const repairs = [];
  for (const doc of documents.filter((d) => existingNames.has(d.name))) {
    const entries = pack.index.filter((entry) => entry.name === doc.name);
    for (const entry of entries) {
      const existing = await pack.getDocument(entry._id);
      if (existing && existing.system.slug !== doc.system.slug) {
        repairs.push({ document: existing, slug: doc.system.slug });
      }
    }
  }

  if (missing.length === 0 && repairs.length === 0) return;

  const wasLocked = pack.locked;
  if (wasLocked) await pack.configure({ locked: false });
  try {
    if (missing.length > 0) {
      await Item.implementation.createDocuments(missing, { pack: packId });
      console.log(
        `${MODULE_ID} | Added to ${packId}: ${missing.map((d) => d.name).join(", ")}`
      );
    }
    for (const { document, slug } of repairs) {
      await document.update({ "system.slug": slug });
      console.log(`${MODULE_ID} | Repaired slug on ${document.name} in ${packId}.`);
    }
  } finally {
    if (wasLocked) await pack.configure({ locked: true });
  }
}

async function seedCompendia() {
  const defs = Object.values(VIALS);
  await seedPack(`${MODULE_ID}.items`, defs.map((def) => vialItemData(def)));
  await seedPack(`${MODULE_ID}.effects`, defs.map((def) => coatingEffectData(def)));
}

/* -------------------------------------------- */
/*  Hooks                                       */
/* -------------------------------------------- */

Hooks.once("setup", () => {
  game.settings.register(MODULE_ID, "vialDataVersion", {
    scope: "world",
    config: false,
    type: String,
    default: "",
  });

  // Intercept vial consumption so a vial is only spent when a coat is applied.
  const Consumable = CONFIG.PF2E?.Item?.documentClasses?.consumable;
  if (Consumable?.prototype?.consume) {
    const original = Consumable.prototype.consume;
    Consumable.prototype.consume = async function (...args) {
      if (vialDefFor(this)) return applyVial(this);
      return original.apply(this, args);
    };
  } else {
    console.error(
      `${MODULE_ID} | Could not patch consumable use; vial coating automation disabled.`
    );
  }
});

Hooks.once("ready", async () => {
  const module = game.modules.get(MODULE_ID);
  module.api = { applyVial, seedCompendia };

  Hooks.on("createChatMessage", (message) => {
    onAttackOrDamageMessage(message).catch((error) =>
      console.error(`${MODULE_ID} | Vial coating expiry failed`, error)
    );
  });

  if (game.user.isGM) {
    const seeded = game.settings.get(MODULE_ID, "vialDataVersion");
    if (seeded !== DATA_VERSION) {
      await seedCompendia();
      await game.settings.set(MODULE_ID, "vialDataVersion", DATA_VERSION);
    }
  }
});
